E19 PC Icons v5 - Baby Legends support

Built on the working All Forms Fix v4 (including the Zygarde fix).

Baby Legends 2.4 species added:
Articoo -> Articuno
Beta -> Arceus
Courpup male -> Zamazenta
Courpup female -> Zacian
Creslume -> Cresselia
Delcalf -> Kyogre
Foreroar -> Suicune
Fulguroar -> Raikou
Giragrub -> Giratina
Haidon -> Koraidon
Kaidon -> Miraidon
Karfoal -> Keldeo
Latot male -> Latios
Latot female -> Latias
Myu -> Mew
Myutu -> Mewtwo
Neonite -> Necrozma
Ohho -> Ho-Oh
Raygul -> Rayquaza
Regiclay -> Regigigas (representative for the branching Regi line)
Rotisikree -> Moltres
Saladune -> Groudon
Statchic -> Zapdos
Temga -> Dialga
Vertrice -> Virizion
Volcaroar -> Entei
Xerfawn -> Xerneas
Yangram -> Kyurem (representative for the Reshiram/Zekrom/Kyurem branching line)
Yivpip -> Yveltal
Zerpint -> Zygarde

Also added:
Royal Carbink -> Diancie

Normal and shiny aliases are included. Latot and Courpup preserve gender-specific
adult icons, with additional common bucket/standard runtime aliases.
