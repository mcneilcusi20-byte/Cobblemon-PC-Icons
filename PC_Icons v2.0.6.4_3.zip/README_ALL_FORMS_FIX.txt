E19 Cobblemon PC Icons — All Forms Fix v3

Targets:
- Minecraft 1.21.1
- Cobblemon 1.7.3
- Mega Showdown 1.8.4
- Cobblemon PC Icons 2.0.6.2

Mapped alternate forms: 347
Generated exact form/aspect aliases: 4117

This build reads the actual Cobblemon and Mega Showdown form/aspect definitions and
creates exact PC-icon aliases for them. 2.0.6.2 also refuses to display the generic
normal 2D sprite for a Pokemon carrying a real alternate-form aspect. If no matching
E19 alternate sprite exists, it falls back to Cobblemon's 3D model instead of showing
the wrong normal icon.
