E19 Cobblemon Minimap Icons -> Cobblemon PC Icons conversion

Target mod:
  Cobblemon PC Icons 2.0.5.1
  Minecraft 1.21.1 / Cobblemon 1.7.3

Converted source folders:
  regular
  shiny
  radiant
  alatia

PC icon destination:
  assets/cobblemon/textures/pc_icons/

Behavior with Cobblemon PC Icons 2.0.5.1:
  - Matching converted sprite: 2D icon
  - No matching sprite: Cobblemon's original 3D model

The converter emitted multiple safe filename aliases for species whose Cobblemon
display name/resource ID differs from the E19 filename, plus aspect/form aliases
for shiny, gender, regional, Mega/Gigantamax and other suffixes where possible.

Generated icon files: 8539
Conflicting destination names skipped: 852
